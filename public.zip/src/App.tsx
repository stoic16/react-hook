import { useState } from 'react'
import { HashRouter, Route, Routes,Link } from 'react-router-dom'
import Home from './views/home/index.tsx'
import User from './views/user/index.tsx'
import Layout from './views/layout/index.tsx'

function App() {

  return (
    <HashRouter>
      <Link to="/">Layout</Link>
      <Link to="/home">Home</Link>
      <Link to="/user">User</Link>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="home" element={<Home />} />
          <Route path="user" element={<User />} />
        </Route>
      </Routes>
    </HashRouter>
  )
}

export default App
