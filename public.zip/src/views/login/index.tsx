import { Outlet} from 'react-router-dom'
function Login() {
  return (
    <div>
      登录
      <Outlet />
    </div>
  )
}
export default Login