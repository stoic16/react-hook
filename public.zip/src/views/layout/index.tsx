import './layout.scss'
import { Outlet } from 'react-router-dom'
function Layout() {
  return (
    <section id="container">
      <aside>aisde</aside>
      <section className="right">
        <header>header</header>
        <main>
          <Outlet />
        </main>
      </section>
    </section>
  )
}

export default Layout
